//
//  Task.swift
//  TasksTimer
//
//  Created by lc on 2019/5/29.
//  Copyright © 2019 lc. All rights reserved.
//

import Foundation

extension NSNotification.Name {
    public static var timerCount: NSNotification.Name = NSNotification.Name("TimerCount")
}

class GlobalTimer {
    
    static let shared : GlobalTimer = GlobalTimer()
    var internalTimer: Timer?
    
    func startTimer() {
        guard self.internalTimer == nil else {
            return
        }
        self.internalTimer = Timer.scheduledTimer(timeInterval: 1.0 /*seconds*/, target: self, selector: #selector(fireTimer), userInfo: nil, repeats: true)
        //self.internalTimer?.fire()
    }
    
    func stopTimer() {
        guard self.internalTimer != nil else {
            return
        }
        self.internalTimer?.invalidate()
    }
    
    @objc func fireTimer(sender: Any) {
        NotificationCenter.default.post(name: .timerCount, object: nil)
        debugPrint("Timer Fired! \(String(describing: sender))")
    }
    
}


class Task {
    var title: String = ""
    var seconds: Int = 60
    
    var count: Int = 0
    
    var running: Bool = false
    
    var block: ((Task)->())? = nil
    
    
    
    init(title: String, count: Int) {
        self.title  = title
        self.seconds = count
        self.count = count
        GlobalTimer.shared.startTimer()
        NotificationCenter.default.addObserver(self, selector: #selector(countDown), name: .timerCount, object: nil)
        
    }
    
    @objc func countDown() {
        if running {
            if count > 0 {
                self.count = self.count - 1
                print( String(seconds) + "   --------   " + String(self.count))
                block?(self)
            } else {
                running = false
            }
        }
    }
}


// MARK: - Time extensions
extension Int {
    
    public var seconds: Int      { return self % 3600 % 60 }
    
    public var minutes: Int      { return self / 60 }
    
    public var hours: Int        { return self / 3600 }
}
