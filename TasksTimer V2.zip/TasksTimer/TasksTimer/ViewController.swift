//
//  ViewController.swift
//  TasksTimer
//
//  Created by lc on 2019/5/29.
//  Copyright © 2019 lc. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        let tap = UITapGestureRecognizer(target: self, action: #selector(toTask))
        view.addGestureRecognizer(tap)

    }

    @objc func toTask() {
        performSegue(withIdentifier: "show", sender: nil)
    }

}

