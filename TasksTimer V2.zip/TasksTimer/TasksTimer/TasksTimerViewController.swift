//
//  TasksTimerViewController.swift
//  TasksTimer
//
//  Created by lc on 2019/5/29.
//  Copyright © 2019 lc. All rights reserved.
//

import UIKit

class TasksTimerViewController: UIViewController {

    var tasks: [Task] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()

        title = "Multiiple Task Timer"
        
        let task = Task(title: "", count: 60)
        tasks.append(task)
        
    }
    
    @IBAction func add() {
        
    }
}


extension TasksTimerViewController: UITableViewDataSource {

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return tasks.count
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "TaskCell", for: indexPath) as! TaskCell
        let task = tasks[indexPath.row]
        
        task.block = { t in
            cell.titelField.text = t.title
            cell.hoursField.text = String(format: "%02d", t.count.hours)
            cell.minutesField.text = String(format: "%02d", t.count.minutes)
            cell.secondsField.text = String(format: "%02d", t.count.seconds)
            cell.playButton.isSelected = task.running
        }
        
        cell.titelField.text = task.title
        cell.hoursField.text = String(format: "%02d", task.count.hours)
        cell.minutesField.text = String(format: "%02d", task.count.minutes)
        cell.secondsField.text = String(format: "%02d", task.count.seconds)
        
        cell.playButton.isSelected = task.running
        
        cell.clickHandle = {
            task.title = cell.titelField.text ?? ""
            /// 开始
            if !cell.playButton.isSelected {
                
            }
            if task.count > 0 {
                task.running = !task.running
                cell.playButton.isSelected = !cell.playButton.isSelected
            }
        }
        return cell
    }
    
}

extension TasksTimerViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 200
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: false)
        
    }
}




class TaskCell: UITableViewCell {
    
    var clickHandle: (()->())?
    
    @IBOutlet weak var playButton: UIButton!
    
    @IBOutlet weak var titelField: UITextField!
    
    @IBOutlet weak var hoursField: UITextField!
    @IBOutlet weak var minutesField: UITextField!
    @IBOutlet weak var secondsField: UITextField!
    
    
//    var info: Task? {
//        didSet {
//            if let task = info {
//                titelField.text = task.title
//                hoursField.text = String(format: "%02d", task.count.hours)
//                minutesField.text = String(format: "%02d", task.count.minutes)
//                secondsField.text = String(format: "%02d", task.count.seconds)
//
//                playButton.isSelected = task.running
//            }
//        }
//    }
    
    @IBAction func beginOrPause(_ sender: UIButton) {
        self.endEditing(true)
        if !sender.isSelected {
            [titelField, hoursField, minutesField, secondsField].forEach({$0.isEnabled = false})
        } else {
            [titelField, hoursField, minutesField, secondsField].forEach({$0.isEnabled = true})
        }
        clickHandle?()
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
    
    
}
