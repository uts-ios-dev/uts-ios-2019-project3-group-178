//
//  Task.swift
//  TasksTimer
//
//  Created by lc on 2019/5/29.
//  Copyright © 2019 lc. All rights reserved.
//

import Foundation

struct Task {
    var title: String = ""
    var seconds: Int = 60
    
    var count: Int = 0
    
    var running: Bool = false
    
}
