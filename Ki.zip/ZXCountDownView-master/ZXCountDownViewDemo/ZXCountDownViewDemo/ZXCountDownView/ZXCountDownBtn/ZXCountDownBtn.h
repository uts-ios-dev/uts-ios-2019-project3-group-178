

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN
typedef NSString *(^textFormatBlock) (long remainSec);

@interface ZXCountDownBtn : UIButton
-(void)initOpr;

@property(nonatomic,assign)BOOL disableScheduleStore;

-(void)setCountDown:(long)countDownSec mark:(NSString *)mark resTextFormat:(textFormatBlock)textFormat;

-(void)startCountDown;

-(void)reStartCountDown;

-(void)stopCountDown;

-(void)invalidateTimer;
@end

NS_ASSUME_NONNULL_END
