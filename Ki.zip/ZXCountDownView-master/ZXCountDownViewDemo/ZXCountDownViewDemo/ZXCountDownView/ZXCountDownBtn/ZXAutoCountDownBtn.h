

#import <UIKit/UIKit.h>
#import "ZXCountDownBtn.h"
NS_ASSUME_NONNULL_BEGIN

@interface ZXAutoCountDownBtn : ZXCountDownBtn

-(void)enableAutoCountDown:(long)countDownSec mark:(NSString *)mark resTextFormat:(textFormatBlock)textFormat;

@property(nonatomic,assign)BOOL start;

-(void)resume;
@end

NS_ASSUME_NONNULL_END
