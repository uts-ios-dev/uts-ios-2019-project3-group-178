

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSDate (ZXCountDownTime)
///Get current time stamp
+(long)getTimeStamp;
///transfer second to time
+(NSString *)getDateStrWithSec:(long)sec dateFormat:(NSString *)dateFormat;
@end

NS_ASSUME_NONNULL_END
