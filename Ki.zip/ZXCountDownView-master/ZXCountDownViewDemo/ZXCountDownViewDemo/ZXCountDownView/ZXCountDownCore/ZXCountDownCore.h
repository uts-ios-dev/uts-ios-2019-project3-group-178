

#import <Foundation/Foundation.h>
typedef void(^countDownBlock) (long remainSec);
NS_ASSUME_NONNULL_BEGIN
@interface ZXCountDownCore : NSObject

@property(nonatomic,assign)BOOL disableScheduleStore;

-(void)setCountDown:(long)countDownSec mark:(NSString *)mark resBlock:(countDownBlock)resBlock;
///start time count down
-(void)startCountDown;
///restart count down
-(void)reStartCountDown;
///end count down
-(void)stopCountDown;
///get the remain time through mark
///close count down timer
-(void)invalidateTimer;
///invalide time
-(long)getDisTimeWithMark:(NSString *)mark;
@end

NS_ASSUME_NONNULL_END
