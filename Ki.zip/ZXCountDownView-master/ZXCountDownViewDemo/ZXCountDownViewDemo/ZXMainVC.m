

#import "ZXMainVC.h"
#import "ZXCountDownView.h"
@interface ZXMainVC()
@property (weak, nonatomic) IBOutlet ZXCountDownLabel *scheduleStoreLabel;

@property (weak, nonatomic) IBOutlet ZXCountDownLabel *normalLabel;
@property (weak, nonatomic) IBOutlet ZXCountDownBtn *scheduleStoreBtn;
@property (weak, nonatomic) IBOutlet ZXAutoCountDownBtn *getCheckCodeBtn;

@end

@implementation ZXMainVC

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"Kitchen Alram";
    [self initScheduleStoreLabel];
    [self initNormalLabel];
    [self initScheduleStoreBtn];
    [self initGetCheckCodeBtn];
}

#pragma mark BeefBrisketLabel
-(void)initScheduleStoreLabel{
    [self.scheduleStoreLabel setCountDown:5400 mark:@"ScheduleStoreLabel" resTextFormat:^NSString *(long remainSec){
        NSString *timeformatStr = [NSDate getDateStrWithSec:remainSec dateFormat:@"mm：ss"];
         return [NSString stringWithFormat:@"Only %@ S",timeformatStr];
        
    }];
}

#pragma mark GarlicChikenLabel
-(void)initNormalLabel{
    self.normalLabel.disableScheduleStore = YES;
    [self.normalLabel setCountDown:330 mark:@"NormalLabel" resTextFormat:^NSString *(long remainSec) {
        NSString *timeformatStr = [NSDate getDateStrWithSec:remainSec dateFormat:@"mm：ss"];
        return [NSString stringWithFormat:@"Only %@ S",timeformatStr];
    }];
}

#pragma mark RoastLambChopsBtn
-(void)initScheduleStoreBtn{
    [self.scheduleStoreBtn setCountDown:600 mark:@"ScheduleStoreBtn" resTextFormat:^NSString *(long remainSec) {
        NSString *timeformatStr = [NSDate getDateStrWithSec:remainSec dateFormat:@"mm：ss"];
        return [NSString stringWithFormat:@"Only %@ S",timeformatStr];
    }];
}

#pragma mark GarlicBreadBtn
-(void)initGetCheckCodeBtn{
    [self.getCheckCodeBtn enableAutoCountDown:120 mark:@"GetCheckCodeBtn" resTextFormat:^NSString *(long remainSec) {
        return [NSString stringWithFormat:@"After%ldsent again",remainSec];
    }];
}
#pragma mark -Action

#pragma mark Click Start
- (IBAction)startAction:(id)sender {
    [self.scheduleStoreLabel startCountDown];
    [self.normalLabel startCountDown];
    [self.scheduleStoreBtn startCountDown];
}
#pragma mark Click End
- (IBAction)stopAction:(id)sender {
    [self.scheduleStoreLabel stopCountDown];
    [self.normalLabel stopCountDown];
    [self.scheduleStoreBtn stopCountDown];
}

#pragma mark CLick reset
- (IBAction)resetAction:(id)sender {
    [self.scheduleStoreLabel reStartCountDown];
    [self.normalLabel reStartCountDown];
    [self.scheduleStoreBtn reStartCountDown];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
@end
