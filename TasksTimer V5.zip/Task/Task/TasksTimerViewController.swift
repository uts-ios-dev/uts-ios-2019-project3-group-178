//
//  TasksTimerViewController.swift
//  TasksTimer
//
//  Created by lc on 2019/5/29.
//  Copyright © 2019 lc. All rights reserved.
//

import UIKit

class TasksTimerViewController: UIViewController {

    @IBOutlet weak var table: UITableView!
    
    var tasks: [Task] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()

        title = "Multiiple Task Timer"
        
        let task = Task(title: "", count: 60)
        tasks.append(task)
        
    }
    
    @IBAction func add() {
        let task = Task(title: "", count: 60)
        tasks.append(task)
        table.reloadData()
    }
}


extension TasksTimerViewController: UITableViewDataSource {

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return tasks.count
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "TaskCell", for: indexPath) as! TaskCell
        let task = tasks[indexPath.row]
        
        task.block = { t in
            cell.titelField.text = t.title
            cell.hoursField.text = String(format: "%02d", t.count.hours)
            cell.minutesField.text = String(format: "%02d", t.count.minutes)
            cell.secondsField.text = String(format: "%02d", t.count.seconds)
            cell.playButton.isSelected = task.running
            /// COUNT DOWN TIME END
            if t.count == 0 {
                cell.hoursField.text = String(format: "%02d", t.seconds.hours)
                cell.minutesField.text = String(format: "%02d", t.seconds.minutes)
                cell.secondsField.text = String(format: "%02d", t.seconds.seconds)
                cell.playButton.isSelected = false
            }
        }
        
        cell.titelField.text = task.title
        cell.hoursField.text = String(format: "%02d", task.count.hours)
        cell.minutesField.text = String(format: "%02d", task.count.minutes)
        cell.secondsField.text = String(format: "%02d", task.count.seconds)
        
        cell.playButton.isSelected = task.running
        
        cell.clickHandle = {
            task.title = cell.titelField.text ?? ""
            /// Start count
            if !cell.playButton.isSelected {
                if let h = cell.hoursField.text, let hours = Int(h), let m = cell.minutesField.text, let minutes = Int(m),
                    let s = cell.secondsField.text, let seconds = Int(s) {
                    let allSeconds = hours * 3600 + minutes * 60 + seconds
                    if allSeconds != task.count { /// 有改动d时间
                        task.seconds = allSeconds
                        task.count = allSeconds
                    }
                }
            }
            if task.count > 0 {
                task.running = !task.running
                cell.playButton.isSelected = !cell.playButton.isSelected
            }
        }
        return cell
    }
    
}

extension TasksTimerViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 200
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: false)
        
    }
}




class TaskCell: UITableViewCell {
    
    var clickHandle: (()->())?
    
    @IBOutlet weak var playButton: UIButton!
    
    @IBOutlet weak var titelField: UITextField!
    
    @IBOutlet weak var hoursField: UITextField!
    @IBOutlet weak var minutesField: UITextField!
    @IBOutlet weak var secondsField: UITextField!

    
    @IBAction func beginOrPause(_ sender: UIButton) {
        self.endEditing(true)
        if !sender.isSelected {
            [titelField, hoursField, minutesField, secondsField].forEach({$0.isEnabled = false})
        } else {
            [titelField, hoursField, minutesField, secondsField].forEach({$0.isEnabled = true})
        }
        clickHandle?()
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
    
    
}
